# 文件清单与 MD5（自动生成）

- 生成时间：2026-10-30 13:40:42
- 根目录：`D:\Users\daaa\紫光同创_赛题三_交付包_2026-10-30`
- 文件总数：**247**，合计 **7.79 MB**（8,166,179 B）

## 0. 按顶层目录统计

| 顶层目录 | 文件数 | 大小 |
|---|---:|---:|
| `(根目录)` | 1 | 8.4 KB |
| `00_交付说明` | 3 | 11.4 KB |
| `01_技术文档` | 5 | 86.0 KB |
| `02_演示视频` | 4 | 16.5 KB |
| `03_硬件实物` | 3 | 6.3 KB |
| `04_工程源码与运行包` | 214 | 6.31 MB |
| `05_上板与复现` | 3 | 13.4 KB |
| `06_数据与证据` | 11 | 1.32 MB |
| `07_答辩材料` | 3 | 15.7 KB |

## 1. 关键冻结件校验（与 README/文档口径一致）

- `04_工程源码与运行包/run/BASELINE_hdmi_loop_E819B0EF.sbit`<br>MD5 `e819b0efb79ec59dd7736ef0bb9355db` 期望 `E819B0EFB79EC59DD7736EF0BB9355DB` → ✅ 一致
- `04_工程源码与运行包/src_adas/adas_20261028.tar.gz`<br>MD5 `206ce366e6bfe9829e49cd2703d9bb7a` 期望 `206ce366e6bfe9829e49cd2703d9bb7a` → ✅ 一致

> 板端 app 的 MD5 无法从 PC 包直接计算（app 不在包内，是板端 `/userdata/high_speed_pcie/camera_capture_v2`），核对值见 `00_交付说明/已知问题与统一答辩口径.md`。

## 2. 完整清单（路径 | 大小 | MD5）

```
README.md	8573	60801cc3cfaa144deaa8d2fa82f30d6e
00_交付说明/已知问题与统一答辩口径.md	4182	5ef720713fc671e38775db671db8c12d
00_交付说明/提交材料对照表.md	6133	be16bfe271ca469054bda65d81bc181c
00_交付说明/队伍信息_待填.md	1358	c6f2c9534b2c70a20f0b46da42888f45
01_技术文档/技术文档_赛题三_ADAS系统.docx	32676	5a914b64c50d4eab4734c1c7054fab08
01_技术文档/技术文档_赛题三_ADAS系统.md	35169	38043399aeee8a2813ca43d284db4e99
01_技术文档/核心亮点预览.docx	13604	448be13d2281053e4d29387422e12e11
01_技术文档/核心亮点预览.md	3676	07879719b458fcf5f43c53a8907572b6
01_技术文档/附件_资源占用与时序.md	2903	8b6bd0c2d2dbf67159893b0c23854daa
02_演示视频/分镜脚本_3分钟.md	8101	10fd7a8ffa17227b2cda0f7c63d7ad3f
02_演示视频/录制清单_操作版.md	4856	c4acce90eff5be71432ad547ac072303
02_演示视频/成片放这里.md	348	b58ea19c86e02554a617743fac5f9ee1
02_演示视频/提交说明与命名规范.md	3574	7bff502eb155af4baba89274b7d2c4d0
03_硬件实物/实物照片_拍摄要求.md	2155	f36f88451f73ccd75e19363aa9669d0d
03_硬件实物/硬件清单与接线.md	3926	e2787e925823f82b21f52f3de3e7ed6c
03_硬件实物/照片/README_待补拍.md	342	ff70e15a730abeab85ca7493d10e8307
04_工程源码与运行包/README.md	9415	0ffdedb0056ecba86fad387f8b216e94
04_工程源码与运行包/board/adas_build3.sh	1821	d8d598e3441059748356e6248333ee23
04_工程源码与运行包/board/adas_keys.sh	502	ce7bee31433fb76b4c26ebcfc2f715a9
04_工程源码与运行包/board/allinone.sh	1467	dbfc68bec51aa1be3acff0d7ea627927
04_工程源码与运行包/board/plain_start.sh	803	d1a970b502700dca18d8e406de36df9d
04_工程源码与运行包/board/regwrite.c	992	35e2f8a80f70f03e8ed54435e6d49254
04_工程源码与运行包/board/start_60.sh	3818	6f72c218c1448d1ffc2d69f69c3590d6
04_工程源码与运行包/board/verify.sh	708	0e9922f0c114f8f08e3d025c5154d638
04_工程源码与运行包/docs/ADAS_60HZ_2026-10-28.md	3514	abb99f34fc8160ceac936b0e5dd989fa
04_工程源码与运行包/docs/README_标准版.md	5134	6f02c6b51482e377989edc3df50005ea
04_工程源码与运行包/docs/RUNBOOK_BASELINE.md	4356	64b4345bd50e5e69b8e8eb0c5ae83d92
04_工程源码与运行包/docs/基础跑通版_RUNBOOK.md	4356	64b4345bd50e5e69b8e8eb0c5ae83d92
04_工程源码与运行包/docs/赛题三_完成度评估与演示视频脚本_2026-10-28.md	14816	e62033daba7b9244ca54e28be35e329d
04_工程源码与运行包/log/cfg.log	1552	000082f6471098170670179567ede5bf
04_工程源码与运行包/log/configuration.log	4493	455f50c924e22cda6ba8fa811e44dfbc
04_工程源码与运行包/log/js.log	432	720d92a78eb5627e3d6f008f29b635b2
04_工程源码与运行包/log/jtagserver.log	4248	15a0f814c68e8e2f37fdc3559837dd57
04_工程源码与运行包/run/BASELINE_hdmi_loop_E819B0EF.sbit	2113704	e819b0efb79ec59dd7736ef0bb9355db
04_工程源码与运行包/run/MD5SUMS.txt	13451	01b6d0397107223ae05e2bd89f06ded0
04_工程源码与运行包/run/RUN_STANDARD.ps1	6886	bb06d95f5a5aa4ed14e9e647bf7dea38
04_工程源码与运行包/run/configuration_tcl.log	536	d0e105acdd26d83db256446d2118fe57
04_工程源码与运行包/run/flash_baseline.tcl	247	ea346aca033b8d21ab50223f02da1645
04_工程源码与运行包/run/rk.py	11855	cce8413c18d7da5cb1818965cae14eb2
04_工程源码与运行包/run/rkget.py	3434	26b1cd4535f9154887dada21a0c8382b
04_工程源码与运行包/run/setdisp.ps1	3172	24bdd34e82759d3983044f8b68a553f6
04_工程源码与运行包/run/setdisp_types.cs	2393	e2f94704fc89379c77ee007df9e569c5
04_工程源码与运行包/shots/adas60_20261028_175943.jpg	198876	d38aa8643916c4f3610efa31d1c60d99
04_工程源码与运行包/shots/adas_off_60.jpg	90636	53b3b679794f353cac26b26a55d4b094
04_工程源码与运行包/shots/adas_on_60.jpg	101517	4473ed5c3898c0610daa04e735ccdfc7
04_工程源码与运行包/shots/baseline_20261028_144951.jpg	88419	4da51391257b18ec71f813023c506d82
04_工程源码与运行包/shots/det_60fps_1028.jpg	95313	449140e286e6f41728cdbb179cbaba6b
04_工程源码与运行包/shots/live_60fps_1028.jpg	136531	a2d92da09e480451d2cacacf8efa8002
04_工程源码与运行包/shots/pinned_ok.jpg	113920	5741587f96f4580fa76307c4cf6f3eb3
04_工程源码与运行包/shots/stab_60_1028.jpg	174376	35a13051b5da782bf37307e17a9b4805
04_工程源码与运行包/shots/standard_20261028_1810.jpg	187799	af234511994193e54abec19bdb2cbe94
04_工程源码与运行包/shots/standard_20261028_182046.jpg	190757	46f7cc79119937a6643eb93677c08f26
04_工程源码与运行包/src_adas/README.md	10202	7f8540e485875b85cb00c66afa8b4d53
04_工程源码与运行包/src_adas/adas_20261028.tar.gz	31674	206ce366e6bfe9829e49cd2703d9bb7a
04_工程源码与运行包/src_adas/adas_bridge.cpp	7469	abd2d5027573e784525b229b7aa9903d
04_工程源码与运行包/src_adas/adas_bridge.h	5547	c27fe6f1caa5ddb00b267972d31667a6
04_工程源码与运行包/src_adas/adas_decision.h	9448	2aba55464864aa30a3793f610949161b
04_工程源码与运行包/src_adas/adas_glue.cpp	6482	aafb758384fa5d47c483d33efee463d7
04_工程源码与运行包/src_adas/adas_glue.h	2633	ac6a6088c7098de8a9a4ade9d727c3be
04_工程源码与运行包/src_adas/adas_lane_type.cpp	8247	f71ce5259732b38d9a17e28728d3c01c
04_工程源码与运行包/src_adas/adas_lane_type.h	1991	138955bb66b747600b2b7667c78ebc2e
04_工程源码与运行包/src_adas/adas_overlay.cpp	16811	026d65cb4a7b3985826e07f6088e0351
04_工程源码与运行包/src_adas/adas_overlay.h	502	e8804cea7641e1bf3c48d6529c9f1f4d
04_工程源码与运行包/src_adas/adas_patch.py	15019	75ef1207565deb84affd5f7a7beaa16a
04_工程源码与运行包/src_adas/build_on_board.sh	1549	a528256b290b815f38e4ad6cc6467204
04_工程源码与运行包/src_adas/test/test_adas_logic.cpp	17868	55b1d026f732e0446aa8b9d30622e798
04_工程源码与运行包/src_arm/#U4eca#U65e5#U8c03#U6574#U6574#U5408#U8bf4#U660e_2026-07-24.md	2679	9d156400ad732c41f032e1549c4af556
04_工程源码与运行包/src_arm/.qmake.stash	699	300d16ad4cab1df2b4189e20bbad77a9
04_工程源码与运行包/src_arm/CCPD_E2E_TEST.md	2344	aeb670bbd938dab01418d2f2e67069a1
04_工程源码与运行包/src_arm/FPS41_DEBUG_HANDOFF.md	7458	4be6353c4381b48fea803b758d0c4331
04_工程源码与运行包/src_arm/IP_CAMERA_USAGE.md	2255	f20b3b0550154645a1be193f247ea33f
04_工程源码与运行包/src_arm/LANE_CENTER_POINT_TRIAL.md	1040	caf9e3d395c916a3da0b597e5081c5e1
04_工程源码与运行包/src_arm/LANE_DEPARTURE.md	2019	3a0e12ccfc1460ed23fe75c3f6c737e4
04_工程源码与运行包/src_arm/LANE_DIRECTION_RED_YELLOW_COMPARE.md	1596	0086f06624111988c031a31c40bdcb0c
04_工程源码与运行包/src_arm/LANE_TRIANGLE_ROI_TRIAL.md	1768	8e4c89673638dd12b789dc79bcb6bfed
04_工程源码与运行包/src_arm/LPR_BLUESPECIAL_BATCH_TEST.md	2687	ad13203dd8719df6847dfccae2a87dc1
04_工程源码与运行包/src_arm/Makefile	42206	e544617008d597bc5adb797d5440d362
04_工程源码与运行包/src_arm/Makefile.codex_check.Release	175529	73bda14ffeabfa5f1d04be40cb8083df
04_工程源码与运行包/src_arm/NU_.Release	176984	2925280fdb1469e33a01d5605852c568
04_工程源码与运行包/src_arm/PLATE_PREPROCESS_DUAL_TEST.md	2688	9ab477bc207d066bf2808a8160911fdb
04_工程源码与运行包/src_arm/YOLOPV2_INTEGRATION.md	2350	a2fcdfbe164adcc9cd44776ba76e3c24
04_工程源码与运行包/src_arm/YOLOV8_YIELD_INTEGRATION.md	1032	070b8c200e1bf26b616431c713ef252e
04_工程源码与运行包/src_arm/camera_display.pro	3028	8c508931a1e6a121b7856c8d68454cf6
04_工程源码与运行包/src_arm/ccpd_e2e_test.cpp	32088	ae3a06f2f455dda11c0f8f7431147054
04_工程源码与运行包/src_arm/ccpd_e2e_test.pro	507	85da0e00761c81e18bf6d247ec62103d
04_工程源码与运行包/src_arm/check_display_120.sh	1413	dcf3176e2a46b8121ff9a0c32dd1ce2e
04_工程源码与运行包/src_arm/collect_fps41_system_state.sh	2911	d08ba0ac1aef6694cccef66fb520f969
04_工程源码与运行包/src_arm/detection_worker.cpp	47279	9935d84be8df1bc420215717e6ee89bf
04_工程源码与运行包/src_arm/detection_worker.h	8184	daf6b4a831786f097468218d2b89ad86
04_工程源码与运行包/src_arm/eglfs_video_window.cpp	57662	5ce83abdf426f2e4192a7fa329b19455
04_工程源码与运行包/src_arm/eglfs_video_window.h	8949	9c4a5d3bf2d494aac0ed631ef7098922
04_工程源码与运行包/src_arm/frame_buffer.h	8703	92b55417fb0387a48dce2443eb08c63c
04_工程源码与运行包/src_arm/frame_capture.cpp	57626	fa2db1fc4c942033926562770e9b7a25
04_工程源码与运行包/src_arm/frame_capture.h	1938	317d280bf44cbc2513d249efcc30910c
04_工程源码与运行包/src_arm/generate_ccpd_e2e_manifest.py	2852	3fd0a05ab60e782138a71b14634ee845
04_工程源码与运行包/src_arm/helmet_detector.cpp	7514	4363cb372dd9ad57b1bfbfabc4960545
04_工程源码与运行包/src_arm/helmet_detector.h	945	ea82d4ea152cf3eb3d1b582b12241419
04_工程源码与运行包/src_arm/helmet_worker.cpp	2644	0fd7f8ef9c489819ff17ca6cc4b00aff
04_工程源码与运行包/src_arm/helmet_worker.h	1251	5cfa496977ff412bc8ef0aa054329bc7
04_工程源码与运行包/src_arm/image_converter.cpp	5577	7d497002e9266cc50ff99be4e92a33a2
04_工程源码与运行包/src_arm/image_converter.h	1796	7be5e5b3a428a958f544a4e8bd63b520
04_工程源码与运行包/src_arm/ip_camera_receiver.cpp	11447	d89251e045c56a397c3caa21ceb43068
04_工程源码与运行包/src_arm/ip_camera_receiver.h	1476	f8c284fcd74c13550a71a3e78f75e207
04_工程源码与运行包/src_arm/kms.json	161	cb5c72e4e53330ba3ee91085aaad1650
04_工程源码与运行包/src_arm/kms_1080p120.json	271	7ee48446ab33e78f05fde26181bf5604
04_工程源码与运行包/src_arm/kms_720p120.json	244	4242f6aafd237aeb2699d7e1ea847aaf
04_工程源码与运行包/src_arm/kms_720p80.json	160	e236938b734bbdeb05a7cbd785e97937
04_工程源码与运行包/src_arm/kms_720p80_forced.json	205	42b09bca3c5d7f7012bccf70951b185d
04_工程源码与运行包/src_arm/lane_departure_analyzer.cpp	30739	e047455ab833feddfda87e55290fb2c7
04_工程源码与运行包/src_arm/lane_departure_analyzer.h	1422	786207377f7c682b60b278129af824b0
04_工程源码与运行包/src_arm/lpr_bluespecial_batch_test.cpp	20628	785db326e96a0f405f369572ac6dbb31
04_工程源码与运行包/src_arm/lpr_bluespecial_batch_test.pro	431	1ade5b4ef988272d5f7698e7563e6b4d
04_工程源码与运行包/src_arm/lprnet.cc	35735	1f807d540769f2604f39ef5da7428431
04_工程源码与运行包/src_arm/lprnet.h	2298	608c71bee9027aa1c6dcdc4007df401e
04_工程源码与运行包/src_arm/main.cpp	10860	35a05cb8f185552b54e03932e4e39b2a
04_工程源码与运行包/src_arm/mainwindow.cpp	122241	c37215f842000e2935a36455f730dba8
04_工程源码与运行包/src_arm/mainwindow.h	11857	40117768920410c068a892602a9dcd7e
04_工程源码与运行包/src_arm/obb_detector.cpp	23719	14586a713801530ed910c72a022b2ee5
04_工程源码与运行包/src_arm/obb_detector.h	3070	e06a97e6b85fcae3a731856ebc0a631d
04_工程源码与运行包/src_arm/obb_postprocess.cpp	16750	1d7f4aa4a5626830ceb936a1b734c515
04_工程源码与运行包/src_arm/obb_postprocess.h	1095	611244bfb7d7067d1c0901b8a2b79b03
04_工程源码与运行包/src_arm/object_script.camera_capture_v2.Release	752	a0d7f6ef5500346370b2a108d0458689
04_工程源码与运行包/src_arm/overlay_renderer.cpp	23367	83ee309a1e512f3626344e4290fca9c8
04_工程源码与运行包/src_arm/overlay_renderer.h	1819	394d08998984c6984c2e562b9f2353bf
04_工程源码与运行包/src_arm/pango_pci_driver.ko	134888	bd541d068ddf937a6dffad7c2bcfcd8b
04_工程源码与运行包/src_arm/pcie_device.cpp	29830	aa341cb882e2eba2b5cee50dcd82815e
04_工程源码与运行包/src_arm/pcie_device.h	5266	b13c3ad08391e1502c741a5d494f167d
04_工程源码与运行包/src_arm/plate_preprocess_dual_test.cpp	27765	e00a6fd8ea6e121899c21a0d355775cb
04_工程源码与运行包/src_arm/plate_preprocess_dual_test.pro	501	ad69e8af5217cce286a5ce520f6ef87e
04_工程源码与运行包/src_arm/plate_preprocess_rknn.cpp	10361	bba9ee7070e0ce8249fac2860a1edef6
04_工程源码与运行包/src_arm/plate_preprocess_rknn.h	2099	7867f9999a1338fffcb6e5a567e0badb
04_工程源码与运行包/src_arm/qplatformnativeinterface_compat.h	3112	ce2584fa37a9214f69548210adf46e45
04_工程源码与运行包/src_arm/recover_rk_system_pipeline.sh	6522	d3caa379d68c1038ae327312f88691d6
04_工程源码与运行包/src_arm/rknn_api.h	35707	a9345f4c4ed053467579aafe4a534408
04_工程源码与运行包/src_arm/run1080p120.sh	268	1d58b81820d17370937d481bc78518fb
04_工程源码与运行包/src_arm/run_camera.sh	7318	72924cba7b5724042846b10e99139541
04_工程源码与运行包/src_arm/run_camera_1080p120.sh	2476	a9a40af60c34b3783c6d1d104df166cc
04_工程源码与运行包/src_arm/run_camera_60.sh	1486	c76e588e2124f6d0184ba98bd839138f
04_工程源码与运行包/src_arm/run_camera_80.sh	4708	1c75f1b4b331409c6bfcc282af72c2c0
04_工程源码与运行包/src_arm/run_camera_80_forced.sh	778	dbca43697ebecff5243453e5b50c6e9c
04_工程源码与运行包/src_arm/single_test_rknn.cpp	5996	2edbbbd77920d3df956f09851a2bd777
04_工程源码与运行包/src_arm/traffic_detector.cpp	14192	dfb9cd565c830487e6e6e9ad073ace43
04_工程源码与运行包/src_arm/traffic_detector.h	961	f31cf8f27bd411d7c9f42ff092017ab9
04_工程源码与运行包/src_arm/traffic_worker.cpp	2364	0bed69aa9c1e0eb690252ea34850ad76
04_工程源码与运行包/src_arm/traffic_worker.h	1185	05c3964be6011fac9757ac24ddee8142
04_工程源码与运行包/src_arm/video_frame_widget.cpp	9647	f38b69d40248f5c471147f011002df49
04_工程源码与运行包/src_arm/video_frame_widget.h	2330	19a7cf8b1cd7902cec0a8bb56ba7bbe6
04_工程源码与运行包/src_arm/video_pipeline_multi_input.md	18714	41e495e75db45bef122aaa22c9876962
04_工程源码与运行包/src_arm/video_pipeline_technical_doc.md	17392	5ba9184fa2e5000be56b9b55acd4029c
04_工程源码与运行包/src_arm/wifi_control.cpp	11231	4665da3de90d7c0dfb91efc99f66013c
04_工程源码与运行包/src_arm/wifi_control.h	3263	9d0d76747b29a7e7d6ef8be5df22769d
04_工程源码与运行包/src_arm/wifi_discovery.cpp	2585	e875d9bfae17c9666f8ff166b4485714
04_工程源码与运行包/src_arm/wifi_discovery.h	1242	1556561167083e8cb80c674475affc41
04_工程源码与运行包/src_arm/wifi_receiver.cpp	8934	01296fe862087218af8f44c75ad8a4c7
04_工程源码与运行包/src_arm/wifi_receiver.h	2742	70be0768fbaff5e84f72a58812dfeb4c
04_工程源码与运行包/src_arm/yolov8_detector.cpp	40926	ce8324529d173fe828c3ffd04f1c377c
04_工程源码与运行包/src_arm/yolov8_detector.h	6414	7c9b60801b08f16afb99fb0b38242b77
04_工程源码与运行包/src_arm/yolov8_worker.cpp	9996	d8dd581d11bf27014f3d656c9932fba4
04_工程源码与运行包/src_arm/yolov8_worker.h	2360	7ed0ad1f44c4940a625a0f65506ad1a4
04_工程源码与运行包/src_arm/adas/adas_decision.h	9448	2aba55464864aa30a3793f610949161b
04_工程源码与运行包/src_arm/adas/adas_decision.h.b64	4346	811bc24b23e07e466ab7902c2e1ba05f
04_工程源码与运行包/src_arm/adas/adas_demo	72784	d6cc7afe167d7412b49a2058b2ed6e19
04_工程源码与运行包/src_arm/adas/adas_demo.c	26596	cdc653862d1ad58f05d69922ba4e5ac9
04_工程源码与运行包/src_arm/adas/adas_demo.c.b64	12547	343e496964bee06ef1d5128784b680a3
04_工程源码与运行包/src_arm/adas/adas_view	73712	7e4f7b316a1b009d6a85d76ed345ae6a
04_工程源码与运行包/src_arm/adas/adas_view.c	24610	a93464f706385fdebaeae02efa944d95
04_工程源码与运行包/src_arm/adas/adas_view.c.b64	11667	19ce9b8ae4da13125a83add77ac0995a
04_工程源码与运行包/src_arm/adas/adas_yolo.h	11408	868f41779597e1d77ec3a3e0678976d9
04_工程源码与运行包/src_arm/adas/adas_yolo.h.b64	5612	0070e2109b617ee5872208facea7f68d
04_工程源码与运行包/src_arm/adas/fb_probe	71368	80345cef674d1d4b0e5409caeb04614c
04_工程源码与运行包/src_arm/adas/fb_probe.c	4124	41586e315c07e94bca9b63fcad773ac4
04_工程源码与运行包/src_arm/adas/fb_probe.c.b64	2537	cfdf20f52c6cc9a1b7f61d9a28ad3d40
04_工程源码与运行包/src_arm/adas/lane_diag	71312	aedde0d1d6fb34848fddacf2b94a8658
04_工程源码与运行包/src_arm/adas/lane_diag.c	6167	d7388b9c8e2720c0f3d9e6fec8cc1200
04_工程源码与运行包/src_arm/adas/lane_diag.c.b64	3413	a0d0585231e836d5a235a6924914a729
04_工程源码与运行包/src_arm/adas/qt_eglfs_test	79832	ada2c13b207014e9ca872b9bc959c2b6
04_工程源码与运行包/src_arm/adas/qt_eglfs_test.cpp	2674	265a2091edd29eedd0799b3058f7532e
04_工程源码与运行包/src_arm/adas/qt_eglfs_test.cpp.b64	1846	c239dca0bb7151344e56bbdc9e191800
04_工程源码与运行包/src_arm/adas/rknn_api.h	35707	a9345f4c4ed053467579aafe4a534408
04_工程源码与运行包/src_arm/adas/rknn_api.h.b64	9721	eb80db24d4c4205c592e7092b62cacb0
04_工程源码与运行包/src_arm/adas/rknn_info	71336	3cf9cb7c280e97a441f94505d24d3bf7
04_工程源码与运行包/src_arm/adas/rknn_info.c	3572	7a9b87a2dfd6a94ceaac3d8b0ad79971
04_工程源码与运行包/src_arm/adas/rknn_info.c.b64	1986	61c5b681954655b96fff1a5c5e5b38af
04_工程源码与运行包/src_arm/adas/yolo_debug	72144	07fd5e013c82b2ca2c8360de2e044916
04_工程源码与运行包/src_arm/adas/yolo_debug.c	8140	91ac502b197d01596db02cf7f4c5d897
04_工程源码与运行包/src_arm/adas/yolo_debug.c.b64	4692	b036759f86cecde6f764d06b3d97cd23
04_工程源码与运行包/src_arm/third_party/librga/README.md	363	68b7dd7315043fbdf9ad400812d499fa
04_工程源码与运行包/src_arm/third_party/librga/include/GrallocOps.h	1627	5c85fd432fb897390638714b5b370e1c
04_工程源码与运行包/src_arm/third_party/librga/include/RgaApi.h	2272	2020e46a4f5d94a2cf6a1bdb9d7aa107
04_工程源码与运行包/src_arm/third_party/librga/include/RgaMutex.h	6213	640ee1cef3c0a66735e5da970f607fad
04_工程源码与运行包/src_arm/third_party/librga/include/RgaSingleton.h	1882	725278c52fb2ebc8d855520968957644
04_工程源码与运行包/src_arm/third_party/librga/include/RgaUtils.h	1230	ddc5cb17cfffbf15dc4a402a3c1df391
04_工程源码与运行包/src_arm/third_party/librga/include/RockchipRga.h	3477	8efffcf60c4996700d518daac06dcb14
04_工程源码与运行包/src_arm/third_party/librga/include/drmrga.h	9359	9ac573bb1c6a40fce421f80e135e54b0
04_工程源码与运行包/src_arm/third_party/librga/include/im2d.h	945	3dfe0984b4bbf8d03adef6e6e8986909
04_工程源码与运行包/src_arm/third_party/librga/include/im2d.hpp	825	0ecfd13e156a72db3b662bb40b08e73f
04_工程源码与运行包/src_arm/third_party/librga/include/im2d_buffer.h	6868	d64de26ebc41afa52cc022eef0b04b8f
04_工程源码与运行包/src_arm/third_party/librga/include/im2d_common.h	4735	94b76dc4b3336abb9ef9d8c567581298
04_工程源码与运行包/src_arm/third_party/librga/include/im2d_expand.h	1437	0b6c4a2006884b1ab0e8e706b2b41262
04_工程源码与运行包/src_arm/third_party/librga/include/im2d_mpi.h	2666	7e56ac663f5a9c9ce647da89d427e84c
04_工程源码与运行包/src_arm/third_party/librga/include/im2d_single.h	30523	95987d9e232532afcc2e373ec1a8da10
04_工程源码与运行包/src_arm/third_party/librga/include/im2d_task.h	14710	fcf462752b42b48ec44809060d4322e3
04_工程源码与运行包/src_arm/third_party/librga/include/im2d_type.h	14081	d0c9c19aedd41e1189f19c5a58f45cc6
04_工程源码与运行包/src_arm/third_party/librga/include/im2d_version.h	1683	caf56ba38681b63caf71eb1d346104dc
04_工程源码与运行包/src_arm/third_party/librga/include/rga.h	9505	55b46941e80f66bea8cfea252d52a2b4
04_工程源码与运行包/src_arm/third_party/librga/lib/librga.a	349970	e453d3880b1bfd13dbca9d38aeeccb74
04_工程源码与运行包/src_arm/wifi_connect/requirements.txt	60	9e307c21ad0a9dce8c4feadbabcc41e0
04_工程源码与运行包/src_arm/wifi_connect/stream_server.py	5918	69a3c15e2b949bc50fc34b94b669bd09
04_工程源码与运行包/src_arm/wifi_connect/wifi_connect_gui.py	38238	32d4a49a7a752136df48b78dfa4d8ffd
04_工程源码与运行包/src_fpga/fdc/hdmi_loop.fdc	13783	99aae1eefa5dc93069f876e9d0c7bc33
04_工程源码与运行包/src_fpga/fdc/hdmi_loop.fdc.camera	16494	2bb56a9911a3dc99469264c944a0b18a
04_工程源码与运行包/src_fpga/rtl/binarize.v	1461	2d23aaade5b5d3e6a40305a0fbc70a7f
04_工程源码与运行包/src_fpga/rtl/color_detect_roi.v	6131	a8e8df6f69180269713e9f2d116573d1
04_工程源码与运行包/src_fpga/rtl/dbg_hdmi.v	4443	160d62aa633db478cced9477e838218f
04_工程源码与运行包/src_fpga/rtl/disp_prep.v	7627	7ba7f2de40be811d7c171d1f4183f3f1
04_工程源码与运行包/src_fpga/rtl/frame_diff_motion.v	6184	6dc91caafb0f0217c8fddd5ae343df76
04_工程源码与运行包/src_fpga/rtl/gaussian_3x3.v	3404	689cf4fcf08c3bc9f00780dc592991e2
04_工程源码与运行包/src_fpga/rtl/hdmi_loop.v	44943	da4cfe8138c5885b5b14464ff7b1aa4b
04_工程源码与运行包/src_fpga/rtl/iic_dri.v	15801	75c510b86cf7e480fe9bdf935c76d914
04_工程源码与运行包/src_fpga/rtl/img_proc_pipeline.v	9143	086f6cd64e2f8f01e0366e92cebdb8c7
04_工程源码与运行包/src_fpga/rtl/line_buffer_3x3.v	7403	7184bc41277b245a721d6c011cb4132a
04_工程源码与运行包/src_fpga/rtl/med9_28ce.v	5795	b210a2eaa9be23907c00b3e1e7c23ba9
04_工程源码与运行包/src_fpga/rtl/ms7200_ctl.v	31324	fa1e62a2b895863dbeb7609bd3133695
04_工程源码与运行包/src_fpga/rtl/ms7210_ctl.v	11483	c0b2c2231a0a728b37a180af6195fc4e
04_工程源码与运行包/src_fpga/rtl/ms72xx_ctl.v	10447	6531b7ddfcd3ebf319864e835569fc47
04_工程源码与运行包/src_fpga/rtl/pio_crtl.v	16090	d9d120474949fd6d37ca24d71e40d7b7
04_工程源码与运行包/src_fpga/rtl/rgb565_to_gray.v	3355	be65d47659155eef55bd97db8afa97a2
04_工程源码与运行包/src_fpga/rtl/sobel_edge.v	4414	13761bbcc6775fb1b4523f331d70f801
04_工程源码与运行包/src_tools/keyinject.c	4172	7fccedba13c9c75f3aca86cad80e9f7b
04_工程源码与运行包/src_tools/pcie_check.c	17713	cb65c441ddf6451fca2675ef90487590
05_上板与复现/快速复现_一键脚本.md	3992	b39bbece3e03e23df324a1da39722e0d
05_上板与复现/换机复现_环境依赖.md	5487	811c1be4dee2a98f9269305e1369478a
05_上板与复现/现场故障速查.md	4226	acf60aaaa297c809cb7a0a7b2dea68b5
06_数据与证据/实测数据表.md	6981	0258650abe6f808279954f49afec5dbd
06_数据与证据/screenshots/adas60_20261028_175943.jpg	198876	d38aa8643916c4f3610efa31d1c60d99
06_数据与证据/screenshots/adas_off_60.jpg	90636	53b3b679794f353cac26b26a55d4b094
06_数据与证据/screenshots/adas_on_60.jpg	101517	4473ed5c3898c0610daa04e735ccdfc7
06_数据与证据/screenshots/baseline_20261028_144951.jpg	88419	4da51391257b18ec71f813023c506d82
06_数据与证据/screenshots/det_60fps_1028.jpg	95313	449140e286e6f41728cdbb179cbaba6b
06_数据与证据/screenshots/live_60fps_1028.jpg	136531	a2d92da09e480451d2cacacf8efa8002
06_数据与证据/screenshots/pinned_ok.jpg	113920	5741587f96f4580fa76307c4cf6f3eb3
06_数据与证据/screenshots/stab_60_1028.jpg	174376	35a13051b5da782bf37307e17a9b4805
06_数据与证据/screenshots/standard_20261028_1810.jpg	187799	af234511994193e54abec19bdb2cbe94
06_数据与证据/screenshots/standard_20261028_182046.jpg	190757	46f7cc79119937a6643eb93677c08f26
07_答辩材料/三人分工与交付时间线.md	4534	6e67b304a10635544360dde6db0cfd54
07_答辩材料/现场演示流程.md	4594	a05758b29794fe49766a7a6f097f1461
07_答辩材料/答辩Q&A.md	6949	1f7b5b0a2e06faa053f78fd329632531
```

## 3. 使用说明

- 校验整包：`certutil -hashfile <文件> MD5`（Windows）或本表逐行比对。
- 本清单不含自身文件；重新生成时用同一脚本即可。
